$(document).ready(function(e) {
                    $("#dialog-confirm").dialog({
                        resizable: false,
                        autoOpen: false,
                        height: 190,
                        modal: false,
                        buttons: {
                            "Yes": function() {
                                //$(this).dialog("close");
                if($('#chkTerms').is(':checked'))
                {}else
                {
                  alert('you must accept our terms and conditions');
                  $(this).dialog("close");
                  return false;
                }
                
                                document.getElementById('form1').submit();
                            },
                            "No": function() {
                                //MM_openBrWindow('terms.php', 'TermsAndCondition', 'scrollbars=yes,width=600,height=600');
                                openFancyBox();
                                $(this).dialog("close");
                            }
                        }
                    });
                    $('#chkTerms').click(function (){
                      if($('#chkTerms').is(':checked')){openFancyBox();}
                    });
                    $(".fancybox").fancybox({
                        'width': '570px',
                        'height': '600px',
                        'autoScale': false,
                        'type': 'iframe',
                        'overlayShow': false,
                        'transitionIn': 'fade',
                        'transitionOut': 'elastic',
                        fitToView: false,
                        autoSize: false
                    });
                    
                    function openFancyBox()
                    {
                      $.fancybox({
                        'width': '570px',
                        'height': '600px',
                        'autoScale': false,
                        'type': 'iframe',
                        'overlayShow': false,
                        'transitionIn': 'fade',
                        'transitionOut': 'elastic',
                        'href': 'terms_conditions.php',
                        fitToView: false,
                        autoSize: false
                    });
                    }

                    $('body').click(function(e) {
                        //TC
                        $("#divTerms").css('display', 'none');
                        //PP
                        $("#div-policy").css('display', 'none');
                    });

                    $('body').mousemove(function(e) {

                        //TC
                        if ($('#divTerms').css('display') != "none")
                        {
                            //console.log( (e.pageX) - (parseInt($('#divTerms').css('left') ) ) );
                            if (
                                    (parseInt($('#divTerms').css('left')) - (e.pageX) > 20) ||
                                    ((e.pageX) - (parseInt($('#divTerms').css('left'))) > 330) ||
                                    (parseInt($('#divTerms').css('top')) - (e.pageY) > 20) ||
                                    ((e.pageY) - (parseInt($('#divTerms').css('top'))) > 330)
                                    )
                            {
                                $('#divTerms').css('display', 'none');
                            }
                        }
                        //PP
                        if ($('#div-policy').css('display') != "none")
                        {
                            //console.log( (e.pageX) - (parseInt($('#divTerms').css('left') ) ) );
                            if (
                                    (parseInt($('#div-policy').css('left')) - (e.pageX) > 20) ||
                                    ((e.pageX) - (parseInt($('#div-policy').css('left'))) > 330) ||
                                    (parseInt($('#div-policy').css('top')) - (e.pageY) > 20) ||
                                    ((e.pageY) - (parseInt($('#div-policy').css('top'))) > 330)
                                    )
                            {
                                $('#div-policy').css('display', 'none');
                            }
                        }
                    });
                    //TC
                    $("#divTerms").mouseleave(function(e) {
                        $("#divTerms").css('display', 'none');
                    });
                    //PP
                    $("#div-policy").mouseleave(function(e) {
                        $("#div-policy").css('display', 'none');
                    });
                    /*$("#divContent").load("termssmall.php", function() {
                        $("#divTerms table").width(300);
                    });*/
                    $("#divContent table").width(300);

                    //TC
                    $(".term").hover(function(event) {

                        //alert($("#divTerms").css('display'));
                        if ($("#divTerms").css('display') != "block")
                        {
                            $("#divTerms").css({display: "block", top: event.pageY + 5, left: event.pageX - 100});
                            $("#div-policy").css({display: "none"});

                        }
                    });
                    
                    //PP
                    $(".policy").hover(function(event) {

                        //alert($("#divTerms").css('display'));
                        if ($("#div-policy").css('display') != "block")
                        {
                            $("#div-policy").css({display: "block", top: event.pageY + 5, left: event.pageX - 100});
                            $("#divTerms").css({display: "none"});

                        }
                    });

                    $("#divClose").click(function(e) {
                        $("#div-policy").css('display', 'none');
                    });
                });
                
                function sure()
                {
                    $( "#dialog-confirm" ).dialog( "open" );
                }